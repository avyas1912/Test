package com.amnoy.a1mandi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1MandiApplicationTests {

	@Test
	void contextLoads() {
	}

}
