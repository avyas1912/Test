package com.amnoy.a1mandi.controller;

public class UserController {

}
