package com.amnoy.a1mandi.service.serviceimpl;

public class UserServiceImpl {

}
