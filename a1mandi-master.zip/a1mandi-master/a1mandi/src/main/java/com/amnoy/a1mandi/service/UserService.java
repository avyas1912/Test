package com.amnoy.a1mandi.service;

public interface UserService {

}
