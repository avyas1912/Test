package com.amnoy.a1mandi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A1MandiApplication {

	public static void main(String[] args) {
		SpringApplication.run(A1MandiApplication.class, args);
	}

}
