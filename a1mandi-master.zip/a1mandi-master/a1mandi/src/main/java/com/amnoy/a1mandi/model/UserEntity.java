package com.amnoy.a1mandi.model;

public class UserEntity {

}
