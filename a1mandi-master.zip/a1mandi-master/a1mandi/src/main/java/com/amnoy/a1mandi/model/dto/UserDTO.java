package com.amnoy.a1mandi.model.dto;

public class UserDTO {

}
