package com.amnoy.a1mandi.repository;

public interface UserRepository {

}
