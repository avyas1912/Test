# a1mandi
A1Mandi is provide mobile based auction &amp; accounting features for Mandi brokers. 
